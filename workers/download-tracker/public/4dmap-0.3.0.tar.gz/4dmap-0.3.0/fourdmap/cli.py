"""4DMap CLI: pin, span, join, fork, walk, doctor, ui.

Author: Aziel Eliab only.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Sequence

from .card import CardError
from .ops import dispatch
from .scope import AUTHOR, DEFAULT_PORT, LIMITATION, PRODUCT, __version__


def _load_cards(path: str | None) -> list[dict]:
    if not path:
        return []
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if isinstance(data, list):
        return data
    if isinstance(data, dict) and isinstance(data.get("cards"), list):
        return data["cards"]
    return [data]


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="4dmap",
        description="4DMap — inspection coordinate frame (4DM-WP-1.0). Not a truth engine.",
        epilog=LIMITATION,
    )
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("version", help="Print package version.")
    p_doc = sub.add_parser("doctor", help="Self-check: hash, illegal join, fork keep, Π-EMPTY. No network.")
    p_doc.add_argument("--json", action="store_true", dest="as_json")
    p_ui = sub.add_parser("ui", help=f"Serve the local UI on 127.0.0.1:{DEFAULT_PORT} (loopback only).")
    p_ui.add_argument("--host", default="127.0.0.1")
    p_ui.add_argument("--port", type=int, default=DEFAULT_PORT)
    sub.add_parser("server", help="Alias of ui.")

    def add_cards(p: argparse.ArgumentParser) -> None:
        p.add_argument("--cards", help="JSON file of existing cards")
        p.add_argument("-o", "--output", help="Write JSON result")

    p_pin = sub.add_parser("pin", help="Pin a T/Δ/Γ/Π card")
    p_pin.add_argument("--t", default=None)
    p_pin.add_argument("--axis", default="T")
    p_pin.add_argument("--src", default="operator")
    p_pin.add_argument("--note", default="T pin")
    p_pin.add_argument("--value", default=None)
    add_cards(p_pin)

    p_span = sub.add_parser("span", help="Span Δ between two pins")
    p_span.add_argument("--from-id", required=True)
    p_span.add_argument("--to-id", required=True)
    add_cards(p_span)

    p_join = sub.add_parser("join", help="Typed join T↔Δ, Δ↔Γ, Γ↔Π, T↔Π")
    p_join.add_argument("--left", required=True)
    p_join.add_argument("--right", required=True)
    p_join.add_argument("--type", dest="join_type", required=True)
    add_cards(p_join)

    p_fork = sub.add_parser("fork", help="Fork a card; both branches are kept")
    p_fork.add_argument("--id", required=True)
    add_cards(p_fork)

    p_walk = sub.add_parser("walk", help="Walk prev hashes from a tip")
    p_walk.add_argument("--tip", required=True)
    add_cards(p_walk)

    p_lens = sub.add_parser("lens", help="Apply a lens; silent → Π-EMPTY")
    p_lens.add_argument("--query", default="")
    add_cards(p_lens)

    p_cap = sub.add_parser("cap", help="ZionPattern cap 75%")
    p_cap.add_argument("--score", type=float, required=True)

    p_demo = sub.add_parser("demo", help="Run the synthetic example (not a real case)")
    p_demo.add_argument("-o", "--output")

    p_export = sub.add_parser("export", help="Export 4DM-CARD JSON")
    add_cards(p_export)
    p_import = sub.add_parser("import", help="Import 4DM-CARD JSON (fail-closed hashes)")
    p_import.add_argument("--bundle", required=True, help="JSON file to import")
    add_cards(p_import)
    p_frame = sub.add_parser("frame-status", help="Inspection-frame status (MASTER-33)")
    add_cards(p_frame)
    p_axis = sub.add_parser("axis-describe", help="Describe T/Δ/Γ/Π + companion cites")
    p_axis.add_argument("--axis", default=None)
    add_cards(p_axis)
    p_trace = sub.add_parser("walk-trace", help="Walk prev chain with axis receipts")
    p_trace.add_argument("--tip", required=True)
    add_cards(p_trace)
    p_chain = sub.add_parser("verify-chain", help="Verify a prev-hash chain")
    p_chain.add_argument("--tip", required=True)
    add_cards(p_chain)
    p_vh = sub.add_parser("verify-hash", help="Verify one 4DM-CARD hash")
    p_vh.add_argument("--id", default=None)
    add_cards(p_vh)
    p_mc = sub.add_parser("memory-cite", help="Optional AKM-TRIAD-1.0 fabric cite (card unchanged)")
    p_mc.add_argument("--id", required=True)
    add_cards(p_mc)
    p_mo = sub.add_parser("memory-observe", help="Build FragGate memory_observe packet from a card")
    p_mo.add_argument("--id", required=True)
    add_cards(p_mo)

    p_lib = sub.add_parser("library-pin", help="Pin a library ingest (event, paper date, lat/lon or gazetteer)")
    p_lib.add_argument("--event", required=True)
    p_lib.add_argument("--date", required=True)
    p_lib.add_argument("--lat", default=None)
    p_lib.add_argument("--lon", default=None)
    p_lib.add_argument("--gazetteer-id", dest="gazetteer_id", default=None)
    p_lib.add_argument("--doc-id", dest="doc_id", default=None)
    p_lib.add_argument("--surface", default="MOCK", choices=("REAL", "MOCK"))
    p_lib.add_argument("--src", default="aziel-corpus")
    p_lib.add_argument("--note", default=None)
    add_cards(p_lib)

    p_plot = sub.add_parser("plot", help="Plot lattice pins + trajectories (not GIS)")
    add_cards(p_plot)

    p_pos = sub.add_parser("possibility", help="Labeled possibility + bayesian hooks on the lattice")
    p_pos.add_argument("--id", default=None)
    p_pos.add_argument("--bayesian", type=float, default=None)
    add_cards(p_pos)

    p_pr = sub.add_parser("pattern-recall", help="Recall recurring patterns from the hashchain lattice")
    add_cards(p_pr)

    p_tip = sub.add_parser("lattice-tip", help="List lattice tips (append-only)")
    add_cards(p_tip)

    p_poi = sub.add_parser("poison-refuse", help="Append a poison feature hash to the refuse set")
    p_poi.add_argument("--feature-h", dest="feature_h", default=None)
    p_poi.add_argument("--event", default=None)
    p_poi.add_argument("--date", default=None)
    p_poi.add_argument("--lat", default=None)
    p_poi.add_argument("--lon", default=None)
    p_poi.add_argument("--gazetteer-id", dest="gazetteer_id", default=None)
    add_cards(p_poi)

    p_nb = sub.add_parser("neighbor-cite", help="Cite Aziel Digital Library + companions on a card")
    p_nb.add_argument("--id", required=True)
    add_cards(p_nb)
    return parser


def _write(result: dict, output: str | None) -> int:
    rendered = json.dumps(result, indent=2, ensure_ascii=False)
    if output:
        Path(output).write_text(rendered + "\n", encoding="utf-8")
    else:
        print(rendered)
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)

    if args.command == "version":
        print(f"{PRODUCT} {__version__}")
        print(f"author {AUTHOR}")
        return 0

    if args.command == "doctor":
        from .doctor import run_doctor

        return run_doctor(as_json=args.as_json)

    if args.command in ("ui", "server"):
        from .server import serve

        serve(host=getattr(args, "host", "127.0.0.1"), port=getattr(args, "port", DEFAULT_PORT))
        return 0

    try:
        if args.command == "demo":
            from .example import EXAMPLE_CARDS

            result = {"ok": True, "synthetic": True, "cards": EXAMPLE_CARDS, "limitation": LIMITATION}
            return _write(result, args.output)
        if args.command == "cap":
            return _write(dispatch("cap", {"score": args.score}), None)
        op_map = {
            "export": "card_export",
            "import": "card_import",
            "frame-status": "frame_status",
            "axis-describe": "axis_describe",
            "walk-trace": "walk_trace",
            "verify-chain": "verify_chain",
            "verify-hash": "verify_hash",
            "memory-cite": "memory_cite",
            "memory-observe": "memory_observe",
            "library-pin": "library_pin",
            "plot": "plot",
            "possibility": "possibility",
            "pattern-recall": "pattern_recall",
            "lattice-tip": "lattice_tip",
            "poison-refuse": "poison_refuse",
            "neighbor-cite": "neighbor_cite",
        }
        op = op_map.get(args.command, args.command)
        cards = _load_cards(getattr(args, "cards", None))
        payload = {k: v for k, v in vars(args).items() if k not in {"command", "cards", "output", "bundle"} and v is not None}
        if args.command == "import":
            payload["bundle"] = _load_cards(args.bundle)
            if isinstance(payload["bundle"], list):
                payload = {"cards": payload["bundle"]}
        if args.command == "possibility" and payload.get("bayesian") is not None:
            payload["bayesian"] = {"label": "bayesian", "value": payload["bayesian"], "cite": "cli"}
        result = dispatch(op, payload, cards)
        result["cards_out"] = cards
        if "card" in result:
            cards = cards + [result["card"]]
            result["cards_out"] = cards
        return _write(result, getattr(args, "output", None))
    except CardError as err:
        print(json.dumps(err.as_dict(), indent=2))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

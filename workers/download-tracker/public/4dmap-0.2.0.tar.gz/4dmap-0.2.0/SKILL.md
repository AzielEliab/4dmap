---
name: 4DMap
description: Use this when inspecting time as four axes (T clock, Δ interval, Γ trajectory, Π pattern). Inspection coordinate frame, not a truth engine, not Lumen, not GIS, not a Node Gate. Hosted /v1 via this Worker and aziel-runtime FragGate slug=4dmap. Dual surface: Worker / Flutter / counted download stay complete human software; agents see display envelopes in chat. This Worker /v1/mesh/* PROXY to aziel-runtime via AZIEL_RUNTIME. Suite mesh default OFF. GET /v1/mesh never enables. QNM-BUILD-1.0 live|locked|isolated. QNS-CD-1.0 cite only. No Node Gate. Author Aziel Eliab.
---

# 4DMap

Four-axis temporal mapping and pattern mapping (4DM-WP-1.0). Version **0.2.0**. Author: **Aziel Eliab**.

**THIS IS:** an inspection coordinate frame. 4DM-CARD receipts (id, t, delta, gamma, pi, prev, src, h, note) plus axis receipts. Ops pin / span / stack / gap / fork / walk / lens / class / cohort / absence / cap / join plus card_new / card_export / card_import / frame_status / axis_describe / walk_trace / verify_chain / verify_hash. Typed joins T↔Δ, Δ↔Γ, Γ↔Π, T↔Π cite TemporalLock / StaticClock / ChronoLock / TrajectoryLock / SpectralLock as inspection inputs only. Fail-closed SHA-256. Forks kept. ZionPattern cap 75%. Π-EMPTY when the lens is silent. Not a Softwares door (`domains_are_doors:false`). FragGate is THE single door.

**THIS IS NOT:** a truth engine; Lumen; GIS 4D; a Node Gate; certified forensics; an identity store. Receipts are not truth. No legal name, home, or county on cards. Π→T backdate, intent, and identity leak refuse.

Always send a normal `User-Agent` (for example `Mozilla/5.0`). Cloudflare Workers may 403 empty agents.

## When to call it

- Pin a clock, span an interval, join two cards, walk a prev chain, export/import JSON, or apply a lens.
- Health / skill / OpenAPI / frame_status. Never invent a person, a county, or a backdated clock.

Hosted `/v1/{op}` is stateless. Cards travel in the JSON body. The Worker does not store a map.

## Endpoints (this Worker)

Host: `https://4dmap-download-tracker.vibelock.workers.dev`

| Method | Path | What |
|--------|------|------|
| GET | `/v1/health` | Liveness. Does not increment downloads. |
| GET | `/v1/skill` | This markdown. Does not increment downloads. |
| GET | `/v1/mesh` | PROXY suite mesh status. Default OFF. Never enables. |
| GET | `/v1/mesh/nodes` | PROXY Live Nodes roster. |
| POST | `/v1/mesh/{enable,disable,join,heartbeat,leave,broadcast}` | PROXY. Bearer required to enable. |
| GET | `/v1/example` | Synthetic cards. Not a real case. |
| GET | `/v1/frame_status` | MASTER-33 inspection-frame status. Not a door. |
| GET | `/v1/axis_describe` | T/Δ/Γ/Π + companion cites. |
| GET | `/llms.txt` | Agent-oriented skill text. |
| POST | `/v1/{pin,span,stack,gap,fork,walk,lens,class,cohort,absence,cap,join}` | Stateless card ops. |
| POST | `/v1/{card_new,card_pin,card_span,card_join,card_walk,card_list,verify_hash}` | FragGate aliases. |
| POST | `/v1/{card_export,card_import,frame_status,axis_describe,walk_trace,verify_chain}` | 0.2.0 read/write ops. |
| POST | `/v1/{memory_cite,memory_observe}` | Optional AKM-TRIAD-1.0 fabric cite/observe. Not a Softwares slug. |

OpenAPI: `https://4dmap-download-tracker.vibelock.workers.dev/openapi.json`

Catalog OpenAPI: `https://aziel-runtime.vibelock.workers.dev/openapi.json`

MCP: `POST https://4dmap-download-tracker.vibelock.workers.dev/mcp`
also `POST https://aziel-runtime.vibelock.workers.dev/mcp`

FragGate is LIVE on aziel-runtime: `fraggate_list` → `fraggate_describe slug=4dmap` → `fraggate_call` (`card_new` / `card_pin` / `card_span` / `card_join` / `card_walk` / `card_list` / `verify_hash` plus `card_export` / `card_import` / `frame_status` / `axis_describe` / `walk_trace` / `verify_chain` / `memory_cite` / `memory_observe`). Softwares bucket **Plain**. Hubs list 4DMap. Agent path remains FragGate only. 4DMap is not an extra door. AKM-TRIAD-1.0 is LIVE fabric (not a Softwares-tab product): optional card cite/observe only; posterior ≠ truth; no history rewrite. Memory writes stay on FragGate `memory_*` / `POST /v1/memory/*`.

## How to call (Mozilla/5.0)

```bash
curl -s -A 'Mozilla/5.0' https://4dmap-download-tracker.vibelock.workers.dev/v1/health

curl -s -A 'Mozilla/5.0' https://4dmap-download-tracker.vibelock.workers.dev/v1/mesh

curl -s -A 'Mozilla/5.0' https://4dmap-download-tracker.vibelock.workers.dev/v1/frame_status

curl -s -A 'Mozilla/5.0' -X POST https://4dmap-download-tracker.vibelock.workers.dev/v1/pin \
  -H 'content-type: application/json' \
  -d '{"t":"2026-09-10T00:00:00Z","src":"synthetic","note":"synthetic T pin"}'
```

## Use with AI clients

Works with ChatGPT (GPT Actions / OpenAI), Grok (xAI), Venice, Claude (Anthropic), Cursor (MCP), Glama (MCP), Perplexity, Microsoft Copilot / Bing, Google Gemini / Vertex, Mistral, Meta AI, Apple Intelligence surfaces, Amazon Q tooling, DuckAssist, You.com, Cohere, and other MCP/OpenAPI-capable assistants.

Import the catalog OpenAPI as a custom tool, GPT Action, or HTTP tool. Connect MCP remotes in Cursor, Glama, and other MCP clients.

## Honest banner

Receipts are not truth. Not Lumen. Not certified forensics. Not GIS 4D. Not a Node Gate.

Paper: 4DM-WP-1.0

Forks are welcome and always allowed.

Worker homepage Live Nodes strip polls `GET /v1/mesh` (default OFF). GET never enables. QNS-CD-1.0 is a hub cite / Worker mesh cross-map only.
